#!/bin/sh
cd /home/ctf
timeout 120 ./binary
